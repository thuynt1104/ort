"""Shared feature utilities."""
